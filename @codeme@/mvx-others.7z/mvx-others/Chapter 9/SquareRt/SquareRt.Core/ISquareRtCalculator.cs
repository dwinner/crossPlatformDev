﻿namespace SquareRt.Core
{
    public interface ISquareRtCalculator
    {
        double Calculate(double number);
    }
}