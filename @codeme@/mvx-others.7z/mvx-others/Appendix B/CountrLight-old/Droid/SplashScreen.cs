using Android.App;
using Android.Content.PM;
using Android.Support.V7.App;
using Countr.Core.ViewModels;
using CountrLight.Droid.Views;
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Views;

namespace CountrLight.Droid
{
    [Activity(
        Label = "Countr"
        , MainLauncher = true
        , Icon = "@mipmap/ic_launcher"
        , Theme = "@style/Theme.Splash"
        , NoHistory = true
        , ScreenOrientation = ScreenOrientation.Portrait)]
    public class SplashScreen : AppCompatActivity
    {
        private static bool initialized;

        protected override void OnCreate(Android.OS.Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.SplashScreen);

            if (!initialized)
            {
                initialized = true;

                var navigationService = new NavigationService();
                navigationService.Configure(nameof(CountersViewModel), typeof(CountersView));
                navigationService.Configure(nameof(CounterViewModel), typeof(CounterView));
                ViewModelLocator.RegisterNavigationService(navigationService);

                SimpleIoc.Default.Register<INavigationService>(() => navigationService);
            }
        }
    }
}
