﻿using Android.App;
using Android.OS;
using Android.Support.V7.Widget;
using Android.Support.V7.App;

namespace CountrLight.Droid.Views
{
    [Activity(Label = "@string/ApplicationName")]
    public class CountersView : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.counters_view);

            var toolbar = FindViewById<Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);

            //var recyclerView = FindViewById<MvxRecyclerView>(Resource.Id.recycler_view);
            //recyclerView.SetLayoutManager(new LinearLayoutManager(this));

            //var callback = new SwipeItemTouchHelperCallback(ViewModel);
            //var touchHelper = new ItemTouchHelper(callback);
            //touchHelper.AttachToRecyclerView(recyclerView);
        }
    }
}