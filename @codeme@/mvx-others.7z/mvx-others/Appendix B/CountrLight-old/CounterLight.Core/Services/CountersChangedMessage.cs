﻿namespace Countr.Core.Services
{
    public class CountersChangedMessage
    {
    }
}
