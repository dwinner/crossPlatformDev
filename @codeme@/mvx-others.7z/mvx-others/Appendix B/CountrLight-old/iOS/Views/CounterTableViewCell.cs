﻿using System;
using Countr.Core.ViewModels;
using Foundation;
using UIKit;

namespace Countr.iOS.Views
{
    public partial class CounterTableViewCell : UITableViewCell
    {
        public void Bind(CounterViewModel viewModel)
        {

        }
    }
}
