﻿using System;

using UIKit;
using GalaSoft.MvvmLight.Views;

namespace CountrLight.iOS.Views
{
    public partial class CounterView : UIViewController
    {
        public CounterView(IntPtr handle) : base(handle)
        {
        }
    }
}

