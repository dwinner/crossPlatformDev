﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CountrLight.Core.Models;
using CountrLight.Core.Repositories;
using CountrLight.Core.Services;
using GalaSoft.MvvmLight.Messaging;
using Moq;
using NUnit.Framework;

namespace CountrLight.Core.Tests.Services
{
    [TestFixture]
    public class CountersServiceTests
    {
        Mock<ICountersRepository> repo;
        Mock<IMessenger> messenger;
        ICountersService service;

        [SetUp]
        public void SetUp()
        {
            repo = new Mock<ICountersRepository>();
            messenger = new Mock<IMessenger>();
            service = new CountersService(repo.Object, messenger.Object);
        }

        [Test]
        public async Task IncrementCounter_IncrementsTheCounter()
        {
            var counter = new Counter { Count = 0 };
            await service.IncrementCounter(counter);
            Assert.AreEqual(1, counter.Count);
        }

        [Test]
        public async Task IncrementCounter_SavesTheIncrementedCounter()
        {
            var counter = new Counter { Count = 0 };
            await service.IncrementCounter(counter);
            repo.Verify(r => r.Save(It.Is<Counter>(c => c.Count == 1)),
            Times.Once());
        }

        [Test]
        public async Task GetAllCounters_ReturnsAllCountersFromTheRepository()
        {
            var counters = new List<Counter>
           {
              new Counter {Name = "Counter1" },
              new Counter {Name = "Counter2" }
           };
            repo.Setup(r => r.GetAll()).ReturnsAsync(counters);
            var results = await service.GetAllCounters(); CollectionAssert.AreEqual(results, counters);
        }

        [Test]
        public async Task DeleteCounter_PublishesAMessage()
        {
            // Act
            await service.DeleteCounter(new Counter());
            // Assert
            messenger.Verify(m => m.Send(It.IsAny<CountersChangedMessage>()));
        }
    }
}