﻿using System.Threading.Tasks;
using CountrLight.Core.Models;
using CountrLight.Core.Services;
using CountrLight.Core.ViewModels;
using GalaSoft.MvvmLight.Views;
using Moq;
using NUnit.Framework;

namespace CountrLight.Core.Tests.ViewModels
{
    [TestFixture]
    public class CounterViewModelTests
    {
        Mock<ICountersService> countersService;
        Mock<INavigationService> navigationService;
        CounterViewModel viewModel;

        [SetUp]
        public void SetUp()
        {
            countersService = new Mock<ICountersService>();
            navigationService = new Mock<INavigationService>();
            viewModel = new CounterViewModel(countersService.Object, navigationService.Object);
        }

        [Test]
        public void Name_ComesFromCounter()
        {
            // Arrange
            var counter = new Counter { Name = "A Counter" };
            // Act
            viewModel.Prepare(counter);
            // Assert
            Assert.AreEqual(counter.Name, viewModel.Name);
        }

        [Test]
        public void Count_ComesFromCounter()
        {
            // Arrange
            var counter = new Counter { Count = 4 };

            // Act
            viewModel.Prepare(counter);

            // Assert
            Assert.AreEqual(counter.Count, viewModel.Count);
        }

        [Test]
        public void SettingName_RaisesPropertyChanged()
        {
            // Arrange
            var propertyChangedRaised = false;
            viewModel.PropertyChanged +=
               (s, e) => propertyChangedRaised = (e.PropertyName == "Name");
            viewModel.Prepare(new Counter());

            // Act
            viewModel.Name = "A Counter";

            // Assert
            Assert.IsTrue(propertyChangedRaised);
        }

        [Test]
        public void IncrementCounter_IncrementsTheCounter()
        {
            // Act
            viewModel.IncrementCommand.Execute(null);
            // Assert
            countersService.Verify(s => s.IncrementCounter(It.IsAny<Counter>()));
        }

        [Test]
        public void IncrementCounter_RaisesPropertyChanged()
        {
            // Arrange
            var propertyChangedRaised = false;
            viewModel.PropertyChanged +=
               (s, e) => propertyChangedRaised = (e.PropertyName == "Count");
            // Act
            viewModel.IncrementCommand.Execute(null);
            // Assert
            Assert.IsTrue(propertyChangedRaised);
        }

        [Test]
        public void DeleteCommand_DeletesTheCounter()
        {
            // Arrange
            var counter = new Counter { Name = "A Counter" };
            viewModel.Prepare(counter);

            // Act
            viewModel.DeleteCommand.Execute(null);

            // Assert
            countersService.Verify(c => c.DeleteCounter(counter));
        }

        [Test]
        public void SaveCommand_SavesTheCounter()
        {
            // Arrange
            var counter = new Counter { Name = "A Counter" };
            viewModel.Prepare(counter);
            // Act
            viewModel.SaveCommand.Execute(null);
            // Assert
            countersService.Verify(c => c.AddNewCounter("A Counter"));
            navigationService.Verify(n => n.GoBack());
        }

        [Test]
        public void CancelCommand_DoesntSaveTheCounter()
        {
            // Arrange
            var counter = new Counter { Name = "A Counter" };
            viewModel.Prepare(counter);
            // Act
            viewModel.CancelCommand.Execute(null);
            // Assert
            countersService.Verify(c => c.AddNewCounter(It.IsAny<string>()), Times.Never());
            navigationService.Verify(n => n.GoBack());
        }
    }
}
