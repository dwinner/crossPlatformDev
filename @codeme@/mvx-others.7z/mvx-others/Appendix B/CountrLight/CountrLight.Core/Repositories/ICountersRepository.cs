﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CountrLight.Core.Models;

namespace CountrLight.Core.Repositories
{
    public interface ICountersRepository
    {
        Task Save(Counter counter);
        Task<List<Counter>> GetAll();
        Task Delete(Counter counter);
    }
}