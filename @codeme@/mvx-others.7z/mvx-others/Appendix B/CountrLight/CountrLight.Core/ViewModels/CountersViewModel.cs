﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using System.Windows.Input;
using CountrLight.Core.Models;
using CountrLight.Core.Services;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Views;

namespace CountrLight.Core.ViewModels
{
    public class CountersViewModel : ViewModelBase
    {
        readonly ICountersService service;
        readonly INavigationService navigationService;

        public CountersViewModel(ICountersService service, IMessenger messenger, INavigationService navigationService)
        {
            this.service = service;
            this.navigationService = navigationService;
            messenger.Register<CountersChangedMessage>(this, m => ViewModelLocator.RunOnUIThread(async () => await LoadCounters()));
            Counters = new ObservableCollection<CounterViewModel>();
            ShowAddNewCounterCommand = new RelayCommand(ShowAddNewCounter);
        }

        private ObservableCollection<CounterViewModel> _counters;
        public ObservableCollection<CounterViewModel> Counters
        {
            get { return _counters; }
            set { Set(ref _counters, value); }
        }

        public async Task LoadCounters()
        {
            Counters.Clear();
            foreach (var counter in await service.GetAllCounters())
            {
                var viewModel = new CounterViewModel(service, navigationService);
                viewModel.Prepare(counter);
                Counters.Add(viewModel);
            }
        }

        public ICommand ShowAddNewCounterCommand { get; }

        void ShowAddNewCounter()
        {
            navigationService.NavigateTo(nameof(CounterViewModel), new Counter());
        }
    }
}