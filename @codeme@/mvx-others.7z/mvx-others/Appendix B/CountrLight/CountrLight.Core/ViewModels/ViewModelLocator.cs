﻿using System;
using CountrLight.Core.Repositories;
using CountrLight.Core.Services;
using GalaSoft.MvvmLight.Ioc;
using GalaSoft.MvvmLight.Messaging;
using GalaSoft.MvvmLight.Views;

namespace CountrLight.Core.ViewModels
{
    public static class ViewModelLocator
    {
        static ViewModelLocator()
        {
            SimpleIoc.Default.Register<CountersViewModel>();
            SimpleIoc.Default.Register<CounterViewModel>();

            SimpleIoc.Default.Register<ICountersService, CountersService>();
            SimpleIoc.Default.Register<ICountersRepository, CountersRepository>();
            SimpleIoc.Default.Register<IMessenger, Messenger>();
        }

        public static CountersViewModel CountersViewModel => SimpleIoc.Default.GetInstance<CountersViewModel>();
        public static CounterViewModel CounterViewModel => SimpleIoc.Default.GetInstanceWithoutCaching<CounterViewModel>();
        public static INavigationService NavigationService => SimpleIoc.Default.GetInstance<INavigationService>();

        public static void RegisterNavigationService(INavigationService navigationService)
        {
            SimpleIoc.Default.Register(() => navigationService);
        }

        static Action<Action> dispatcher;
        public static void RegisterDispatcher(Action<Action> dispatcherAction)
        {
            dispatcher = dispatcherAction;
        }

        public static void RunOnUIThread(Action action)
        {
            dispatcher(action);
        }
    }
}
