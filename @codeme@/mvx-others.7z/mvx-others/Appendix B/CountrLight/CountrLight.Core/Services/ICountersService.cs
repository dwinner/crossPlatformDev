﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CountrLight.Core.Models;

namespace CountrLight.Core.Services
{
    public interface ICountersService
    {
        Task<Counter> AddNewCounter(string name);
        Task<List<Counter>> GetAllCounters();
        Task DeleteCounter(Counter counter);
        Task IncrementCounter(Counter counter);
    }
}