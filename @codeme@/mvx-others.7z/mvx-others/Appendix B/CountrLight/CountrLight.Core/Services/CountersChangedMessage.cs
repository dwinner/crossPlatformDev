﻿namespace CountrLight.Core.Services
{
    public class CountersChangedMessage
    {
    }
}
