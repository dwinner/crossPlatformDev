﻿using System.Collections.Generic;
using Android.App;
using Android.OS;
using Android.Views;
using Android.Widget;
using CountrLight.Core.Models;
using CountrLight.Core.ViewModels;
using GalaSoft.MvvmLight.Helpers;
using JimBobBennett.MvvmLight.AppCompat;

namespace CountrLight.Droid.Views
{
    [Activity(Label = "Add a new counter")]
    public class CounterView : AppCompatActivityBase
    {
        EditText _counterName;
        EditText CounterName => _counterName ??
            (_counterName = FindViewById<EditText>(Resource.Id.counter_name));

        readonly List<Binding> bindings = new List<Binding>();

        CounterViewModel viewModel;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.counter_view);

            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);

            SupportActionBar.SetDisplayHomeAsUpEnabled(true);

            viewModel = ViewModelLocator.CounterViewModel;

            var navigationService = (AppCompatNavigationService)ViewModelLocator.NavigationService;
            var counter = navigationService.GetAndRemoveParameter<Counter>(Intent);
            viewModel.Prepare(counter);

            bindings.Add(this.SetBinding(() => viewModel.Name, () => CounterName.Text, BindingMode.TwoWay));
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    viewModel.CancelCommand.Execute(null);
                    return true;
                case Resource.Id.action_save_counter:
                    viewModel.SaveCommand.Execute(null);
                    return true;
                default:
                    return base.OnOptionsItemSelected(item);
            }
        }

        public override bool OnCreateOptionsMenu(IMenu menu)
        {
            base.OnCreateOptionsMenu(menu);
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            toolbar.InflateMenu(Resource.Menu.new_counter_menu);
            return true;
        }
    }
}