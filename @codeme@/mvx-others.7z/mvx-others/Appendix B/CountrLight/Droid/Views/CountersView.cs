﻿using Android.App;
using Android.OS;
using Android.Support.Design.Widget;
using Android.Support.V7.Widget;
using Android.Support.V7.Widget.Helper;
using Android.Widget;
using CountrLight.Core.ViewModels;
using GalaSoft.MvvmLight.Helpers;
using JimBobBennett.MvvmLight.AppCompat;

namespace CountrLight.Droid.Views
{
    [Activity(Label = "@string/ApplicationName")]
    public class CountersView : AppCompatActivityBase
    {
        FloatingActionButton _addCounterButton;
        FloatingActionButton AddCounterButton => _addCounterButton ?? 
            (_addCounterButton = FindViewById<FloatingActionButton>(Resource.Id.add_counter_button));

        RecyclerView _recyclerView;
        RecyclerView RecyclerView => _recyclerView ??
            (_recyclerView = FindViewById<RecyclerView>(Resource.Id.recycler_view));

        ObservableRecyclerAdapter<CounterViewModel, CachingViewHolder> adapter;

        CountersViewModel viewModel;

        protected override async void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.counters_view);

            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            SetSupportActionBar(toolbar);

            viewModel = ViewModelLocator.CountersViewModel;

            AddCounterButton.SetCommand(nameof(FloatingActionButton.Click), viewModel.ShowAddNewCounterCommand);
            adapter = viewModel.Counters.GetRecyclerAdapter(BindViewHolder, Resource.Layout.counter_recycler_view);

            RecyclerView.SetLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.Vertical, false));
            RecyclerView.SetAdapter(adapter);

            var callback = new SwipeItemTouchHelperCallback(viewModel);
            var touchHelper = new ItemTouchHelper(callback);
            touchHelper.AttachToRecyclerView(RecyclerView);

            await viewModel.LoadCounters();
        }

        void BindViewHolder(CachingViewHolder holder, CounterViewModel counterVm, int position)
        {
            var name = holder.FindCachedViewById<TextView>(Resource.Id.counter_name);
            var count = holder.FindCachedViewById<TextView>(Resource.Id.counter_count);
            var incrementButton = holder.FindCachedViewById<ImageButton>(Resource.Id.add_image);

            holder.DeleteBinding(name);
            holder.DeleteBinding(count);

            holder.SaveBinding(name, new Binding<string, string>(counterVm, () => counterVm.Name, name, () => name.Text, BindingMode.OneWay));
            holder.SaveBinding(count, new Binding<int, string>(counterVm, () => counterVm.Count, count, () => count.Text, BindingMode.OneWay));
            incrementButton.SetCommand(nameof(ImageButton.Click), counterVm.IncrementCommand);
        }
    }
}