using Android.App;
using Android.Content.PM;
using CountrLight.Core.ViewModels;
using CountrLight.Droid.Views;
using JimBobBennett.MvvmLight.AppCompat;

namespace CountrLight.Droid
{
    [Activity(
        Label = "Countr"
        , MainLauncher = true
        , Icon = "@mipmap/ic_launcher"
        , Theme = "@style/Theme.Splash"
        , NoHistory = true
        , ScreenOrientation = ScreenOrientation.Portrait)]
    public class SplashScreen : AppCompatActivityBase
    {
        private static bool initialized;

        protected override void OnCreate(Android.OS.Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            if (!initialized)
            {
                initialized = true;

                SetContentView(Resource.Layout.SplashScreen);
                var navigationService = new AppCompatNavigationService();
                navigationService.Configure(nameof(CountersViewModel), typeof(CountersView));
                navigationService.Configure(nameof(CounterViewModel), typeof(CounterView));
                ViewModelLocator.RegisterNavigationService(navigationService);
                ViewModelLocator.RegisterDispatcher(AppCompatDispatcherHelper.CheckBeginInvokeOnUI);
            }
        }

        protected override void OnResume()
        {
            base.OnResume();
            ViewModelLocator.NavigationService.NavigateTo(nameof(CountersViewModel));
        }
    }
}
