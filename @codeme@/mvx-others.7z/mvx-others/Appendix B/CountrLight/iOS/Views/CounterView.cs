﻿using System;
using System.Collections.Generic;
using CountrLight.Core.ViewModels;
using GalaSoft.MvvmLight.Helpers;
using UIKit;
using GalaSoft.MvvmLight.Views;
using CountrLight.Core.Models;

namespace CountrLight.iOS.Views
{
    public partial class CounterView : UIViewController
    {
        CounterViewModel viewModel;

        public CounterView(IntPtr handle) : base(handle)
        {
        }

        List<Binding> bindings = new List<Binding>();
        UIBarButtonItem doneButton;

        public override void ViewDidLoad()
        {
            base.ViewDidLoad();

            try
            {
                viewModel = ViewModelLocator.CounterViewModel;

                var navigationService = (NavigationService)ViewModelLocator.NavigationService;
                var counter = (Counter)navigationService.GetAndRemoveParameter(this);
                viewModel.Prepare(counter);

                doneButton = new UIBarButtonItem(UIBarButtonSystemItem.Done);
                NavigationItem.SetRightBarButtonItem(doneButton, false);

                bindings.Add(this.SetBinding(() => viewModel.Name, () => CounterName.Text, BindingMode.TwoWay));
                doneButton.SetCommand(nameof(UIBarButtonItem.Clicked), viewModel.SaveCommand);
            }
            catch { }

        }
    }
}

