// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;
using UIKit;

namespace CountrLight.iOS.Views
{
    [Register ("CountersView")]
    partial class CountersView
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIBarButtonItem AddNewCounterButton { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (AddNewCounterButton != null) {
                AddNewCounterButton.Dispose ();
                AddNewCounterButton = null;
            }
        }
    }
}