﻿using System;
using UIKit;
using CountrLight.Core.ViewModels;
using System.Collections.Generic;
using GalaSoft.MvvmLight.Helpers;

namespace CountrLight.iOS.Views
{
    public partial class CounterTableViewCell : UITableViewCell
    {
        List<Binding> bindings = new List<Binding>();
        CounterViewModel viewModel;
        
        public CounterTableViewCell(IntPtr handle) : base(handle)
        {
        }

        public void Bind(CounterViewModel counterVm)
        {
            foreach (var binding in bindings)
                binding.Detach();

            bindings.Clear();

            viewModel = counterVm;

            bindings.Add(this.SetBinding(() => viewModel.Name, () => CounterName.Text));
            bindings.Add(this.SetBinding(() => viewModel.Count, () => CounterCount.Text));
            IncrementButton.SetCommand(viewModel.IncrementCommand);
        }
    }
}
