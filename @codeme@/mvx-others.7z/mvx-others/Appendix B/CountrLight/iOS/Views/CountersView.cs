﻿using System;
using CountrLight.Core.ViewModels;
using Foundation;
using GalaSoft.MvvmLight.Helpers;
using UIKit;

namespace CountrLight.iOS.Views
{
    public partial class CountersView : ObservableTableViewController<CounterViewModel>
    {
        CountersViewModel viewModel;
        UITableViewSource tableViewSource;

        public CountersView(IntPtr handle)
        {
            Handle = handle;
        }

        public override async void ViewDidLoad()
        {
            base.ViewDidLoad();

            viewModel = ViewModelLocator.CountersViewModel;

            tableViewSource = viewModel.Counters.GetTableViewSource(BindCounterCell,
                                                                    "CounterCell",
                                                                    () => new CountersTableViewSource());
            TableView.Source = tableViewSource;
            TableView.TableFooterView = new UIView();

            AddNewCounterButton.SetCommand(nameof(UIBarButtonItem.Clicked), viewModel.ShowAddNewCounterCommand);

            await viewModel.LoadCounters();
        }

        private void BindCounterCell(UITableViewCell cell, CounterViewModel counterVm, NSIndexPath path)
        {
            ((CounterTableViewCell)cell).Bind(counterVm);
        }
    }
}

