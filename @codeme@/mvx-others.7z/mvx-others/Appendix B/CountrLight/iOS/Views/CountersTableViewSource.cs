﻿using CountrLight.Core.ViewModels;
using Foundation;
using GalaSoft.MvvmLight.Helpers;
using UIKit;

namespace CountrLight.iOS.Views
{
    public class CountersTableViewSource : ObservableTableViewSource<CounterViewModel>
    {
        public override void CommitEditingStyle(UITableView tableView,
                                                UITableViewCellEditingStyle editingStyle,
                                                NSIndexPath indexPath)
        {
            var counter = DataSource[indexPath.Row];
            counter.DeleteCommand.Execute(null);
        }
    }
}
