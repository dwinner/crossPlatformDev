﻿using CountrLight.Core.ViewModels;
using CountrLight.iOS.Views;
using Foundation;
using GalaSoft.MvvmLight.Threading;
using GalaSoft.MvvmLight.Views;
using UIKit;

namespace CountrLight.iOS
{
    [Register("AppDelegate")]
    public class AppDelegate : UIApplicationDelegate
    {
        public override UIWindow Window { get; set; }

        public override bool FinishedLaunching(UIApplication application, NSDictionary launchOptions)
        {
            var navigationService = new NavigationService();
            navigationService.Initialize((UINavigationController)Window.RootViewController);

            navigationService.Configure(nameof(CountersViewModel), nameof(CountersView));
            navigationService.Configure(nameof(CounterViewModel), nameof(CounterView));

            ViewModelLocator.RegisterNavigationService(navigationService);

            DispatcherHelper.Initialize(application);
            ViewModelLocator.RegisterDispatcher(DispatcherHelper.CheckBeginInvokeOnUI);

            return true;
        }
    }
}

